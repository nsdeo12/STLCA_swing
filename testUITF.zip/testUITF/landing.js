var app = angular.module('myApp', ['ngRoute']);
app.controller('myCtrl', function($scope) {
    $scope.labels = ["Download Sales", "In-Store Sales", "Mail-Order Sales"];
    $scope.data = [300, 500, 100];
    $scope.test="hello";
});